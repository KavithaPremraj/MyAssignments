package com.leaftaps.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods{
	
	public CreateLeadPage enterCompanyName(String data) {
		clearAndType(locateElement(Locators.XPATH, "//input[@id='createLeadForm_companyName']"), data);
		reportStep(data+" company name is entered successfully","pass");
		return this;
	}
	public CreateLeadPage enterFirstName(String data) {
		clearAndType(locateElement(Locators.ID, "createLeadForm_firstName"), data);
		reportStep(data+" first name is entered successfully","pass");
		return this;
	}
	public CreateLeadPage getName() {
		captureleadName= getTypedText(locateElement(Locators.ID, "createLeadForm_firstName"));
		System.out.println(captureleadName);
		reportStep("Captured Typed Text Successfully","pass");
		return this;
	}
	
	public CreateLeadPage selectState(String value) 
	{
		selectDropDownUsingText(locateElement(Locators.NAME, "generalStateProvinceGeoId"), value);
		reportStep(" StateName name is Selected successfully","pass");
		return this;
	}
	
	public CreateLeadPage enterLastName(String data) {
		clearAndType(locateElement(Locators.ID, "createLeadForm_lastName"), data);
		reportStep(data+" last name is entered successfully","pass");
		return this;
	}
	
	public ViewLeadPage clickCreateLeadButton() {
		click(locateElement(Locators.NAME, "submitButton"));
		reportStep("Create Lead button is clicked successfully", "pass");
		return new ViewLeadPage();
	}
	
	

}
