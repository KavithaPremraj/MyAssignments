package com.leaftaps.pages;

import org.openqa.selenium.By;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;



public class MyLeadsPage extends ProjectSpecificMethods{
	
	public CreateLeadPage clickCreateLeadLink() {
		click(locateElement(Locators.LINK_TEXT, "Create Lead"));
		reportStep("Create Lead link is clicked", "pass");
		return new CreateLeadPage();
	}
	public FindLeadsPage clickFindLeads()
	{
		click(locateElement(Locators.XPATH, "//a[text()='Find Leads']"));
		reportStep("Find Leads link is clicked", "pass");
		return new FindLeadsPage();
	}

	public FindLeadsPage clickFindLeadsButton() throws InterruptedException {
		click(locateElement(Locators.XPATH, "//button[text()='Find Leads']"));
		reportStep("Find Lead button is clicked successfully", "pass");
		return new FindLeadsPage();
	}

	public FindLeadsPage enterFirstName(String data) {
		clearAndType(locateElement(Locators.XPATH, "//input[@name='firstName'])[3]"), data);
		reportStep(data+" FirstName is entered successfully","pass");
		return new FindLeadsPage();
	}
	

}
