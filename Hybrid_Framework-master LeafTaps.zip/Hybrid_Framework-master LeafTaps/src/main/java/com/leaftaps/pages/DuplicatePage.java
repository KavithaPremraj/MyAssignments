package com.leaftaps.pages;

import com.framework.testng.api.base.ProjectSpecificMethods;

public class DuplicatePage extends ProjectSpecificMethods {
	
	/*
	 * public ViewLeadPage verifyDuplicateTittle() { String createleadtittle =
	 * getDriver().getTitle(); System.out.println("The Tittle is :" +
	 * createleadtittle); return new ViewLeadPage(); }
	 */

	public ViewLeadPage verifyDuplicateTittle() 
		{
			String createleadtittle = getDriver().getTitle();
			System.out.println("The Tittle is :" + createleadtittle);
			return new ViewLeadPage();
		}
}
