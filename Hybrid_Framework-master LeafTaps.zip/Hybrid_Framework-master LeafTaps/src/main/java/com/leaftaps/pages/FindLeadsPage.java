package com.leaftaps.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.When;

public class FindLeadsPage extends ProjectSpecificMethods  {

	
	public FindLeadsPage enterCapturedLeadID(String data) {
		clearAndType(locateElement(Locators.XPATH, "//input[@name='id']"), data);
		reportStep(data+" Captured LeadID is entered successfully","pass");
		return this;
	}

	/*
	 * public FindLeadsPage enterName1() {
	 * clearAndType(locateElement(Locators.XPATH,
	 * "(//input[@name='firstName'])[3]"), captureleadName);
	 * reportStep(captureleadName+" FirstName is entered successfully","pass");
	 * return this; }
	 */
	
	public FindLeadsPage clickFindLeadsButton() throws InterruptedException {
		click(locateElement(Locators.XPATH, "//button[text()='Find Leads']"));
		reportStep("Find Lead button is clicked successfully", "pass");
		return this;
	}
	
	public ViewLeadPage clickOnFirstResultingLead() {
		click(locateElement(Locators.XPATH, "//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a"));
		reportStep("FIrst Resulting Lead button is clicked successfully", "pass");
		return new ViewLeadPage();
	}
	public FindLeadsPage getTextOfFirstResultingLead() {
	captureleadID = getElementText(locateElement(Locators.XPATH, "//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a"));
		reportStep("Captured LeadID successfully", "pass");
		return this;
	}
	public FindLeadsPage getLeadNameOfFirstResultingLead() {
		captureleadName = getElementText(locateElement(Locators.XPATH, "//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a"));
		//captureleadName.replaceAll("a-zA-Z", "");
		reportStep("Captured LeadID successfully", "pass");
			return this;
	}
	
	public FindLeadsPage enterPhoneNumber(String data) {
		clearAndType(locateElement(Locators.XPATH, "//input[@name='phoneNumber']"), data);
		reportStep(data+" phone number is entered successfully","pass");
		
		return this;
	}
	public FindLeadsPage clickPhone() {
		click(locateElement(Locators.XPATH, "//span[text()='Phone']"));
		reportStep("FIrst Resulting Lead button is clicked successfully", "pass");
		return this;
	}
	public FindLeadsPage VerifyNoRecords(String data) {
		verifyExactText(locateElement(Locators.XPATH,"//div[text()='No records to display']"), data);
		reportStep(data+" is matching", "pass");
		return this;
	
}

	public FindLeadsPage enterName() {
		clearAndType(locateElement(Locators.XPATH, "(//input[@name='firstName'])[3]"),captureleadName);
		reportStep(captureleadName+" FirstName is entered successfully","pass");
		return this;
	}
	
	
}
