package com.leaftaps.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;




public class ViewLeadPage extends ProjectSpecificMethods {
	
	public ViewLeadPage verifyViewLeadTittle()
	{
		String Viewleadtittle = getDriver().getTitle();
		System.out.println("The Tittle is :" + Viewleadtittle);
		reportStep("ViewLeadTittile is Displayed", "pass");
		return new ViewLeadPage();
	}
public ViewLeadPage getNameID()
{
	CompanyLeadNameID=getElementText(locateElement(Locators.ID,"viewLead_companyName_sp"));
	reportStep("Captured LeadNameID is Successfully", "pass");
	CLeadID = CompanyLeadNameID.replaceAll("[^0-9]", "");
	System.out.println(CLeadID);
	return this;
	}
	public ViewLeadPage verifyFirstName(String data) {
		verifyExactText(locateElement(Locators.ID,"viewLead_firstName_sp"), data);
		reportStep(data+" is matching with first name", "pass");
		return this;
	}
	
	public EditLeadPage clickEdit() {
		click(locateElement(Locators.XPATH, "//a[text()='Edit']"));
		reportStep("Edit link is clicked", "pass");
		return new EditLeadPage();
		
	}
	public ViewLeadPage confirmTheChangedNameAppears(String data) {
		verifyExactText(locateElement(Locators.ID,"viewLead_companyName_sp"), data);
		reportStep(data+" is matching with COmpany name", "pass");
		return new ViewLeadPage();
	
}

	public DuplicatePage clickDuplicate() {
		click(locateElement(Locators.XPATH, "//a[text()='Duplicate Lead']"));
		reportStep("Duplicate link is clicked", "pass");
		return new DuplicatePage();
	}
	public MyLeadsPage clickDelete() {
		click(locateElement(Locators.XPATH, "//a[text()='Delete']"));
		reportStep("Delete link is clicked", "pass");
		return new MyLeadsPage();
	}

	public ViewLeadPage duplicateCreateLeadButton() {
		click(locateElement(Locators.CLASS_NAME, "smallSubmit"));
		reportStep("Duplicate Create Lead Button is clicked", "pass");
		return this;
		
	}
	
	

	
	
	

}
