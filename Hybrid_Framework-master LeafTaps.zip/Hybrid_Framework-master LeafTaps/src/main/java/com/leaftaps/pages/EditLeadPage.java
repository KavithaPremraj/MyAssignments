package com.leaftaps.pages;

import org.openqa.selenium.By;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class EditLeadPage extends ProjectSpecificMethods {
	
	public ViewLeadPage clickUpdate() {
		click(locateElement(Locators.XPATH, "//td/input[@value='Update']"));
		reportStep("Update link is clicked", "pass");
		return new ViewLeadPage();
	}

	/*
	 * public EditLeadPage changeTheCompanyName(String data) {
	 * clearAndType(locateElement(Locators.XPATH,
	 * "//td/input[@name='companyName']"), data);
	 * reportStep(data+" Company Name entered successfully","pass"); return this; }
	 */

	public EditLeadPage changeTheCompanyName(String data) {
		clearAndType(locateElement(Locators.XPATH, "//td/input[@name='companyName']"), data);
		reportStep(data+" Company Name entered successfully","pass");
		return this;
	}

}
