package com.leaftaps.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.leaftaps.pages.LoginPage;

public class TC005_DeleteLead extends ProjectSpecificMethods
{
	@BeforeTest
	public void setValues()
	{
		testcaseName = "Delete Lead";
		testDescription ="Delete Lead and verify";
		authors="kavitha";
		category ="Smoke";
		excelFileName="DeleteLead";
	}
	@Test(dataProvider = "fetchData",dependsOnGroups="Sanity")
	public void runEditLead(String uName, String pwd, String result) throws InterruptedException, IOException
	{
			new LoginPage().enterUsername(uName)
			.enterPassword(pwd)
			.clickLogin()
			.clickCrmsfaLink()
			.clickLeadsLink()
			.clickFindLeads()
			.enterCapturedLeadID(CLeadID)
			.clickFindLeadsButton()
			.clickOnFirstResultingLead()
			.verifyViewLeadTittle()
			.clickDelete()
			.clickFindLeads()
			.enterCapturedLeadID(CLeadID)
			.clickFindLeadsButton()
			.VerifyNoRecords(result);
			
		}

}
