package com.leaftaps.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.leaftaps.pages.LoginPage;


public class TC004_DuplicateLead extends ProjectSpecificMethods
{
	@BeforeTest
	public void setValues()
	{
		testcaseName = "Duplicate Lead";
		testDescription ="Edit Lead with Company Name";
		authors="kavitha";
		category ="Smoke";
		excelFileName="DuplicateLead";
	}
	@Test(dataProvider = "fetchData",dependsOnGroups="Sanity")
	public void runEditLead(String uName, String pwd,String pnum) throws InterruptedException, IOException
	{
			new LoginPage().enterUsername(uName)
			.enterPassword(pwd)
			.clickLogin()
			.clickCrmsfaLink()
			.clickLeadsLink()
			.clickFindLeads()
			//.clickPhone()
			//.enterPhoneNumber(pnum)
			.enterCapturedLeadID(CLeadID)
			.clickFindLeadsButton()
			//.getLeadNameOfFirstResultingLead()
			.clickOnFirstResultingLead()
			.verifyViewLeadTittle()
			.clickDuplicate()
			.verifyDuplicateTittle()
			.duplicateCreateLeadButton()
			.verifyViewLeadTittle();
		}

}