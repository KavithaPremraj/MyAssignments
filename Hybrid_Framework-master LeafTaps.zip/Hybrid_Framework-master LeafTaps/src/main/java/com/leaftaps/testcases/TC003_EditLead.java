package com.leaftaps.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.leaftaps.pages.LoginPage;


public class TC003_EditLead extends ProjectSpecificMethods
{
	@BeforeTest
	public void setValues()
	{
		testcaseName = "Edit Lead";
		testDescription ="Edit Lead with Company Name";
		authors="kavitha";
		category ="Smoke";
		excelFileName="EditLead";
	}
	@Test(dataProvider = "fetchData",dependsOnGroups="Sanity")
	public void runEditLead(String uName, String pwd,String updatecName) throws InterruptedException, IOException
	{
	new LoginPage()
	.enterUsername(uName)
	.enterPassword(pwd)
	.clickLogin()
	.verifyHomePage()
	.clickCrmsfaLink()
	.clickLeadsLink()
	.clickFindLeads()
	.enterCapturedLeadID(CLeadID)
	//.enterName()
	.clickFindLeadsButton()
	.clickOnFirstResultingLead()
	.clickEdit()
	.changeTheCompanyName(updatecName)
	.clickUpdate()
	.confirmTheChangedNameAppears(updatecName);
	
	
	
	
	
	/*enterUsername(uName)
	.enterPassword(pwd)
	.clickLogin()
	.clickCrmsfaLink()
	.clickLeadsLink()
	.clickFindLeads()
	.enterFirstName(firstName)
	.clickFindLeadsButton()
	.clickOnFirstResultingLead()
	.verify()
	.clickEdit()
	.changeTheCompanyName(updatecName)
	.clickUpdate()
	.confirmTheChangedNameAppears()
	.verifyTitleOfThePage();
	*/
}

}